SELECT *
FROM customers